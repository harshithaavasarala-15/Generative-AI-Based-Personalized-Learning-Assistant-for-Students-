# AI Learning Assistant - Backend Setup

## Quick Start

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Set up environment variables:**
   - Open `.env` file
   - Replace `AIzaSyB9NfkZV8O5nx3y4ehzwZMa52McbAwoXVU` with your actual OpenAI API key

3. **Start the backend server:**
   ```bash
   npm start
   ```
   Or for development:
   ```bash
   npm run dev
   ```

4. **Open your frontend:**
   - Open `index.html` in your browser
   - Navigate to "Personalized Plan" 
   - Enter any topic and click "Generate Plan"

## How it works

- Frontend sends topic to backend API (`/api/generate-plan`)
- Backend calls OpenAI API to generate personalized learning plan
- AI response is displayed in the frontend
- If API fails, falls back to static template

## API Endpoints

- `POST /api/generate-plan` - Generate AI-powered learning plans
- `POST /api/recommendations` - Get topic recommendations

## Requirements

- Node.js installed
- OpenAI API key (get from platform.openai.com)
