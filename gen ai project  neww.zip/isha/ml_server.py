from flask import Flask, request, jsonify
from flask_cors import CORS
import numpy as np
from sklearn.linear_model import LogisticRegression

app = Flask(__name__)
CORS(app)

# Sample training data
# [score, time_taken, attempts]
X = np.array([
    [30, 15, 3],
    [40, 20, 2],
    [60, 12, 1],
    [70, 10, 1],
    [85, 8, 1],
    [90, 7, 1]
])

# Labels: 0 = Beginner, 1 = Intermediate, 2 = Advanced
y = np.array([0, 0, 1, 1, 2, 2])
model = LogisticRegression(max_iter=1000)
model.fit(X, y)

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json
    score = data["score"]
    time_taken = data["time"]
    attempts = data["attempts"]

    prediction = model.predict([[score, time_taken, attempts]])[0]

    levels = {
        0: "Beginner",
        1: "Intermediate",
        2: "Advanced"
    }

    return jsonify({
        "level": levels[prediction]
    })

if __name__ == "__main__":
    app.run(debug=True)