const express = require('express');
const cors = require('cors');
const axios = require('axios');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// OpenAI API endpoint for generating learning plans
app.post('/api/generate-plan', async (req, res) => {
  try {
    const { topic, difficulty, duration } = req.body;
    
    const response = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are an expert educational content creator. Create detailed learning plans with specific steps, resources, and timelines."
        },
        {
          role: "user",
          content: `Create a ${duration} learning plan for ${topic} at ${difficulty} level. Include specific steps, resources, and daily/weekly milestones.`
        }
      ],
      max_tokens: 1000,
      temperature: 0.7
    }, {
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      }
    });

    const plan = response.data.choices[0].message.content;
    res.json({ success: true, plan });
    
  } catch (error) {
    console.error('Error generating plan:', error);
    res.status(500).json({ success: false, error: 'Failed to generate learning plan' });
  }
});

// Simple mock endpoint for recommendations
app.post('/api/recommendations', (req, res) => {
  const { userLevel, interests } = req.body;
  
  const recommendations = [
    { topic: "JavaScript Basics", difficulty: "Beginner", estimatedTime: "2 weeks" },
    { topic: "React Fundamentals", difficulty: "Intermediate", estimatedTime: "3 weeks" },
    { topic: "Node.js Backend", difficulty: "Intermediate", estimatedTime: "4 weeks" }
  ];
  
  res.json({ success: true, recommendations });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
